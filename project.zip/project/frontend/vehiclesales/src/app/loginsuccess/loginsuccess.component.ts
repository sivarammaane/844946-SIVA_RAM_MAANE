import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Graph } from '../highsalevehicalgraph/graph-model'


@Component({
  selector: 'app-loginsuccess',
  templateUrl: './loginsuccess.component.html',
  styleUrls: ['./loginsuccess.component.css']
})
export class LoginsuccessComponent implements OnInit {
  highsale:any[];
  lowsale:any[];
  highsaleacc:any[];
  lowsaleacc:any[];
  highapi: string='http://localhost:9090/accessoryService/highSales/2015-01-01/2018-12-31';
  lowapi: string='http://localhost:9090/accessoryService/lowSales/2015-01-01/2018-12-31';
  highacc: string='http://localhost:9090/accessoryService/accessoriesMax/2015-01-01/2018-12-31';
  lowacc: string='http://localhost:9090/accessoryService/accessoriesMin/2015-01-01/2018-12-31';

  constructor(private http:HttpClient) {
    this.getHighSale(this.highapi);
    this.getLowSale(this.lowapi);
    this.getHighSaleAcc(this.highacc);
    this.getLowSaleAcc(this.lowacc);

   }

  ngOnInit(): void {
  }

  getHighSale(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.highsale = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
  getLowSale(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.lowsale = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
  getHighSaleAcc(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.highsaleacc = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
  getLowSaleAcc(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.lowsaleacc = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
 


}
