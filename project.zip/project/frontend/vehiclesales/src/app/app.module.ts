import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { HighsalevehicalgraphComponent } from './highsalevehicalgraph/highsalevehicalgraph.component';

import { SearchscreenComponent } from './searchscreen/searchscreen.component';
import { ResultscreenComponent } from './resultscreen/resultscreen.component'


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
   
    LoginsuccessComponent,
   
    HighsalevehicalgraphComponent,
   
    
    SearchscreenComponent,
   
    ResultscreenComponent
  ],
  imports: [
    NgxChartsModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
