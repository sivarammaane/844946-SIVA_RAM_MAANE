package com.accessoryService.controller;

import java.text.ParseException;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.accessoryService.DAO.SMSClient;

import com.accessoryService.model.Sales;
import com.accessoryService.model.SalesGraphPojo;

import com.accessoryService.service.SalesService;

@RestController
@RequestMapping("/accessoryService")
public class AccessoryController {
	
	@Autowired
	private SalesService ss;
	@Autowired
	private SMSClient sms;

	
	@GetMapping("/sales")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Sales> readAllSales() {
		
		return null;
	} 
	
	@GetMapping("/highSales/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> findHighSaleVehicle(@PathVariable("sdate") String sdate,
			@PathVariable("edate") String edate) throws ParseException {
		List<SalesGraphPojo> sgp=ss.findHighSale(sdate, edate);
		return sgp;
	}
	
	@GetMapping("/lowSales/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> findLowSaleVehicle(@PathVariable("sdate") String sdate,
			@PathVariable("edate") String edate) throws ParseException {
		List<SalesGraphPojo> sgp=ss.findLowSale(sdate, edate);
		return sgp;
	}
	
	@GetMapping("/sales/{sdate}/{edate}/{modelSeriesYear}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> findByConstraints(@PathVariable("sdate") String sdate,
			@PathVariable("edate") String edate, @PathVariable("modelSeriesYear")
			String modelSeriesYear) throws ParseException {
		System.out.println(edate+sdate+modelSeriesYear);
		List<SalesGraphPojo> sale=ss.findByConstraints(sdate, edate, modelSeriesYear);
		return sale;
	}
	
	@GetMapping("/accessoriesMax/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> getHighSaleAccessory(@PathVariable String sdate,@PathVariable String edate) throws ParseException {
		String modelCode=ss.findHighSaleByModelCode(sdate, edate);
		List<String> accs=sms.getAccessories(modelCode);
		List<SalesGraphPojo> sgp=ss.findHighSaleAccessory(accs,sdate,edate);
		return sgp;
	}
	
	@GetMapping("/accessoriesMin/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> getLowSaleAccessory(@PathVariable String sdate,@PathVariable String edate) throws ParseException {
		String modelCode=ss.findLowSaleByModelCode(sdate, edate);
		List<String> accs=sms.getAccessories(modelCode);
		List<SalesGraphPojo> sgp=ss.findLowSaleAccessory(accs,sdate,edate);
		return sgp;
	}
	


}
