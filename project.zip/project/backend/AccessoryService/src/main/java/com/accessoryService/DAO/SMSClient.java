package com.accessoryService.DAO;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("SERIES-MODEL-SERVICE")
public interface SMSClient {
	
	@GetMapping("/seriesModelService/accessory/{modelCode}")
	List<String> getAccessories(@PathVariable String modelCode);

}
