package com.accessoryService.service;

import java.sql.Date;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accessoryService.DAO.SalesDAO;
import com.accessoryService.DAOImpl.DateFormatter;
import com.accessoryService.model.Axis;
import com.accessoryService.model.Sales;
import com.accessoryService.model.SalesGraphPojo;

@Service
public class SalesService {

	@Autowired
	private SalesDAO saledao;
	@Autowired
	private DateFormatter df;
	
	static String[] region ={"Australia","Germany","India","Russia","USA"};
	
	public List<SalesGraphPojo> findHighSale(String sdate,String edate) throws ParseException{
		List<Sales> sale = saledao.findHighSaleVehicle(df.dateConverter(sdate), df.dateConverter(edate));
		return salesService(sale);
	}
	
	public List<SalesGraphPojo> findLowSale(String sdate,String edate) throws ParseException{
		List<Sales> sale = saledao.findLowSaleVehicle(df.dateConverter(sdate), df.dateConverter(edate));
		return salesService(sale);
	}
	
	public List<SalesGraphPojo> findByConstraints(String sdate,String edate,String smy) throws ParseException{
		List<Sales> sale = saledao.findByConstraints(df.dateConverter(sdate), df.dateConverter(edate),smy);
		return salesService(sale);
	}

	public List<SalesGraphPojo> findHighSaleAccessory(List<String> accs,String sdate,String edate) throws ParseException {
		
		String accessory="";
		Date s=df.dateConverter(sdate);
		Date e=df.dateConverter(edate);
		Map<String,Integer> map=new HashMap<>();
		for(String a:accs) {
			map.put(a,saledao.findAccessorySaleCount(a,s,e));
		}
		accessory=map.entrySet().stream().max(Map.Entry.comparingByValue()).get().getKey();
		List<Sales> sale=saledao.findHighSaleAccessory(accessory, s, e);
		return salesService(sale);
	}
	
	public List<SalesGraphPojo> findLowSaleAccessory(List<String> accs, String sdate, String edate) throws ParseException {
		String accessory="";
		Date s=df.dateConverter(sdate);
		Date e=df.dateConverter(edate);
		Map<String,Integer> map=new HashMap<>();
		for(String a:accs) {
			map.put(a,saledao.findAccessorySaleCount(a,s,e));
		}
		accessory=map.entrySet().stream().min(Map.Entry.comparingByValue()).get().getKey();
		List<Sales> sale=saledao.findHighSaleAccessory(accessory, s, e);
		return salesService(sale);
	}

	public List<SalesGraphPojo> salesService(List<Sales> sale){
		
		Set<String> model = new TreeSet<>();
		for (Sales sa : sale) {
			model.add(sa.getModelSeriesYear().toUpperCase());
		}

		List<SalesGraphPojo> sgp = new LinkedList<>();
		for (String m : model) {
			for (String s : region) {
				List<Axis> axis = new LinkedList<>();
				boolean i = false;
				for (Sales x : sale) {
					if (s.equalsIgnoreCase(x.getRegion()) && m.equalsIgnoreCase(x.getModelSeriesYear())) {
						axis.add(new Axis(x.getYear(), x.getSaleCount()));
						i = true;
					}
				}
				if (i) {
					sgp.add(new SalesGraphPojo(m, s, axis));
				}
			}
		}
		return sgp;
	}

	
	public String findHighSaleByModelCode(String sdate, String edate) throws ParseException {
		return saledao.findHighSaleVehicleByModelCode(df.dateConverter(sdate), df.dateConverter(edate));
		
	}

	public String findLowSaleByModelCode(String sdate, String edate) throws ParseException {
		return saledao.findLowSaleVehicleByModelCode(df.dateConverter(sdate), df.dateConverter(edate));
		
	}


}
