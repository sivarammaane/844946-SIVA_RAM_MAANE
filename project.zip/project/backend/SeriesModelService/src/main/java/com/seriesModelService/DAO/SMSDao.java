package com.seriesModelService.DAO;

import java.util.List;

import org.springframework.context.annotation.Configuration;

@Configuration
public interface SMSDao {

	public List<String> findAllSeries();
	public List<String> findModelYearBySeries(String series);
	public List<String> findModelCodeBySeriesAndYear(String series, String year);
	public List<String> findModelCodeBySeries(String series);
	public List<String> findAccessoryByModelCode(String modelCode);

}
