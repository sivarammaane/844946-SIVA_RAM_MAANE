package com.seriesModelService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.seriesModelService.DAO.AccessoryDAO;
//import com.seriesModelService.DAO.ModelDAO;
//import com.seriesModelService.DAO.ModelYearDAO;
import com.seriesModelService.DAO.SMSDao;
//import com.seriesModelService.DAO.SeriesDAO;

@RestController
@RequestMapping("/seriesModelService")
public class SMSController {
	
//	@Autowired
//	private ModelDAO modeldao;
//	@Autowired
//	private ModelYearDAO modelyeardao;
//	@Autowired
//	private SeriesDAO seriesdao;
//	@Autowired
//	private AccessoryDAO accessorydao;
	
	@Autowired
	private SMSDao sms;
	
	@GetMapping("/series")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findAllSeries(){
		List<String> series=sms.findAllSeries();
		return series;
	}
	
	@GetMapping("/modelyear/{series}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findModelYear(@PathVariable String series){
		List<String> year=sms.findModelYearBySeries(series);
		return year;
	}
	
	@GetMapping("/modelcode/{series}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findModelCode(@PathVariable String series){
		List<String> mcode=sms.findModelCodeBySeries(series);
		return mcode;
	}
	
	@GetMapping("/modelcode/{series}/{year}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findModelCode(@PathVariable String series,@PathVariable String year){
		List<String> mcode=sms.findModelCodeBySeriesAndYear(series, year);
		return mcode;
	}
	
	@GetMapping("/accessory/{modelCode}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> readAllModels(@PathVariable String modelCode){
		System.out.println(modelCode);
		List<String> acces=sms.findAccessoryByModelCode(modelCode);
		return acces;
	}
	
	/*@GetMapping("/series/{modelCode}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> readAllSeries(@PathVariable String modelCode){
		List<String> series=seriesdao.findByModelCode(modelCode);
		return series;
	}
	
	@GetMapping("/modelyear/{modelCode}/{series}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> readAllModelYear(@PathVariable("modelCode") String modelCode,
			@PathVariable("series") String series){
		List<String> modelyear=modelyeardao.findByModelCodeAndSeries(modelCode, series);
		return modelyear;
	}
	
	@GetMapping("/accessory/{modelCode}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> readAllAccessory(@PathVariable("modelCode") String modelCode){
		List<String> accessory=accessorydao.findByModelCode(modelCode);
		return accessory;
	}*/
}
