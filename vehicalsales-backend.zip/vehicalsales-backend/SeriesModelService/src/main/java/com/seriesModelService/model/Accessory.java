package com.seriesModelService.model;

public class Accessory {

	private String modelCode;
	private String accessory;
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getAccessory() {
		return accessory;
	}
	public void setAccessory(String accessory) {
		this.accessory = accessory;
	}
	public Accessory(String modelCode, String accessory) {
		super();
		this.modelCode = modelCode;
		this.accessory = accessory;
	}
}
