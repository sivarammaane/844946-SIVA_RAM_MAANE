package com.seriesModelService.model;

public class Model {

	private String modelName;
	private String modelCode;
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public Model(String modelName, String modelCode) {
		super();
		this.modelName = modelName;
		this.modelCode = modelCode;
	}
	@Override
	public String toString() {
		return "Model [modelName=" + modelName + ", modelCode=" + modelCode + "]";
	}
	
}
