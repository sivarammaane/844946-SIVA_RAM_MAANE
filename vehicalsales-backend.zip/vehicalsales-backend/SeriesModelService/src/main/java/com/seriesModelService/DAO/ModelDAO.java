package com.seriesModelService.DAO;

import java.util.List;

import org.springframework.context.annotation.Configuration;

@Configuration
public interface ModelDAO {
	
	public List<String> findAllModels();

}
