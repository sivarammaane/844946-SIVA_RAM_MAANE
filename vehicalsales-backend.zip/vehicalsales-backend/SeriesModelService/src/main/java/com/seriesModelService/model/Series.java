package com.seriesModelService.model;

public class Series {
	
	private String modelCode;
	private String seriesName;
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getSeriesName() {
		return seriesName;
	}
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}
	public Series(String modelCode, String seriesName) {
		super();
		this.modelCode = modelCode;
		this.seriesName = seriesName;
	}
	

}
