package com.seriesModelService.DAOImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.seriesModelService.DAO.ModelDAO;
import com.seriesModelService.rowMapper.ModelRowMapper;

@Repository
public class ModelDAOImpl implements ModelDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public List<String> findAllModels(){
		
		String sql="SELECT model_code FROM model";
		List<String> model=jdbcTemplate.query(sql, new ModelRowMapper());
		return model;
	}

}
