package com.log.service;

 

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

 

import com.log.model.User;
import com.log.repository.RegistrationRepo;

 

@Service
public class RegistrationService {
    
    @Autowired
    private RegistrationRepo repo;
    
    public User saveUser(User user) {
        return repo.save(user);
            
    }
    
    @Transactional
    public User fetchUserByEmailId(String emailId) {
        return repo.fingByEmailId(emailId);
    }

    @Transactional
    public User fetchUserByEmailIdandPassword(String emailId, String password) {
        return repo.findByEmailIdandPassword(emailId, password);
    }
}
 