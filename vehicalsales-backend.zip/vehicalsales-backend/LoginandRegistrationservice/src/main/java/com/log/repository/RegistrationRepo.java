package com.log.repository;

 

import org.springframework.data.jpa.repository.JpaRepository;

import com.log.model.User;

 

public interface RegistrationRepo extends JpaRepository<User, Integer> {

 

    public User fingByEmailId(String emailId);

 

    public User findByEmailIdandPassword(String emailId, String password);

 

}
 