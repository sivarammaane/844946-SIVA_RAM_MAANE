package com.log.controller;

 

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RestController;

 

import com.log.model.User;
import com.log.service.RegistrationService;

 

@RestController
public class RegistrationController {
    
    @Autowired
    private RegistrationService service;
    
    @PostMapping("/register")
    @CrossOrigin(origins = "http://localhost:4200" )
    public User registerUser(User user) throws Exception {
        String tempid = user.getEmailId();
        User userObj = null;
        if(tempid != null && !"".equals(tempid)) {
            userObj = service.fetchUserByEmailId(tempid);
            if(userObj != null) {
                throw new Exception("User with "+tempid+" is already exist");
            }
        }
        User userobj = null;
        userobj = service.saveUser(user);
        return userobj;
    }
    
    @PostMapping("/login")
    @CrossOrigin(origins = "http://localhost:4200" )
    public User loginUser(User user) throws Exception {
        String tempid = user.getEmailId();
        String temppassword = user.getPassword();
        User userObj = null;
        if(tempid != null && temppassword != null) {
            userObj = service.fetchUserByEmailIdandPassword(tempid, temppassword);
        }
        if(userObj == null) {
            throw new Exception("User does not exist");
        }
        return userObj;
    }
}