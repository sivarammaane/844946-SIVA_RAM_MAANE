package com.accessoryService.DAO;

import java.sql.Date;
import java.util.List;

import org.springframework.context.annotation.Configuration;

import com.accessoryService.model.Sales;

@Configuration
public interface SalesDAO {
	
	public List<Sales> findHighSaleVehicle(Date sdate,Date edate);
	
	public List<Sales> findLowSaleVehicle(Date sdate,Date edate);
	
	public List<Sales> findByConstraints(Date sdate,Date edate,String modelSeriesYear);

}
