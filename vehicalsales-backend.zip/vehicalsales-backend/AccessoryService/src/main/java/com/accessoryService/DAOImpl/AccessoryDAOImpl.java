package com.accessoryService.DAOImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.accessoryService.DAO.AccessoryDAO;
import com.accessoryService.RowMapper.AccessoryRowMapper;
import com.accessoryService.model.Accessory;

@Repository
public class AccessoryDAOImpl implements AccessoryDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Accessory> findBySalesId(int id) {
		String sql="SELECT type,cost from accessory where sales_id=?";
		List<Accessory> query = jdbcTemplate.query(sql, new AccessoryRowMapper(),id);
		return query;
	}

	@Override
	public List<Accessory> fingByAccessoryType(String type) {
		String sql="SELECT type,cost from accessory where type=?";
		List<Accessory> query = jdbcTemplate.query(sql, new AccessoryRowMapper(),type);
		return query;
	}

}
